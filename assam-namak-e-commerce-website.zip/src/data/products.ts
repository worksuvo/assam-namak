export type Variant = {
  weight: string;
  price: number;
};

export type Product = {
  id: string;
  name: string;
  nameHi: string;
  category: 'Black Salt' | 'Pink Salt' | 'Rock Salt' | 'Flavored';
  shortDesc: string;
  description: string;
  healthBenefits: string[];
  uses: string[];
  variants: Variant[];
  images: string[];
  rating: number;
  reviews: number;
};

export const products: Product[] = [
  {
    id: 'kala-namak-premium',
    name: 'Premium Kala Namak (Black Salt)',
    nameHi: 'प्रीमियम काला नमक',
    category: 'Black Salt',
    shortDesc: 'Rich in iron and minerals, perfect for chaats and digestion.',
    description: 'Our Premium Kala Namak is sourced from the pristine Himalayan ranges and processed traditionally. Known for its distinctive sulfurous aroma, it is an essential ingredient in Indian cuisine, adding a tangy umami flavor to your dishes.',
    healthBenefits: [
      'Aids in digestion and reduces heartburn',
      'Rich source of iron and trace minerals',
      'Helps alleviate muscle cramps',
      'Lower sodium content than regular table salt'
    ],
    uses: ['Chaat Masala', 'Raitas', 'Vegan Tofu Scramble (egg flavor)', 'Lemonades (Shikanji)'],
    variants: [
      { weight: '100g', price: 120 },
      { weight: '500g', price: 350 },
      { weight: '1kg', price: 600 }
    ],
    images: ['/images/black-salt.jpg', 'https://images.unsplash.com/photo-1615486171448-4fdcbabddf35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviews: 124
  },
  {
    id: 'himalayan-pink-salt',
    name: 'Pure Himalayan Pink Salt',
    nameHi: 'गुलाबी नमक',
    category: 'Pink Salt',
    shortDesc: 'Unrefined, natural pink salt packed with 84 essential trace minerals.',
    description: 'Hand-mined from the ancient salt deposits of the Himalayas, this pure pink salt is unrefined and free from additives. Its beautiful pink hue comes from the rich iron content. A healthier alternative to processed white salt.',
    healthBenefits: [
      'Balances body pH levels',
      'Improves respiratory function',
      'Promotes hydration by providing trace minerals',
      'Supports healthy blood sugar levels'
    ],
    uses: ['Everyday cooking', 'Salad seasoning', 'Grilled meats and vegetables', 'Bath soaks'],
    variants: [
      { weight: '100g', price: 150 },
      { weight: '500g', price: 400 },
      { weight: '1kg', price: 750 }
    ],
    images: ['/images/pink-salt.jpg', 'https://images.unsplash.com/photo-1517457224213-9118e7e1b5f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviews: 312
  },
  {
    id: 'sendha-namak-rock',
    name: 'Sendha Namak (Rock Salt)',
    nameHi: 'सेंधा नमक',
    category: 'Rock Salt',
    shortDesc: 'Fasting-friendly pure rock salt, ideal for Vrat and daily use.',
    description: 'Sendha Namak is the purest type of rock salt, traditionally consumed during Navratri and other fasting days in India. It is cooling in nature according to Ayurveda and does not contain toxic impurities found in refined salts.',
    healthBenefits: [
      'Highly valued in Ayurveda for cooling effects',
      'Improves appetite and digestion',
      'Helps maintain blood pressure',
      'Soothes sore throats (when used as a gargle)'
    ],
    uses: ['Vrat (fasting) recipes', 'Sabudana Khichdi', 'Daily Indian curries', 'Ayurvedic remedies'],
    variants: [
      { weight: '100g', price: 100 },
      { weight: '500g', price: 300 },
      { weight: '1kg', price: 550 }
    ],
    images: ['https://images.unsplash.com/photo-1507608241416-86566213fc81?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviews: 89
  },
  {
    id: 'garlic-herb-salt',
    name: 'Garlic & Herb Infused Salt',
    nameHi: 'लहसुन और हर्ब नमक',
    category: 'Flavored',
    shortDesc: 'A savory blend of sea salt, roasted garlic, and aromatic herbs.',
    description: 'Elevate your everyday meals with our artisanal Garlic & Herb Infused Salt. We blend premium natural sea salt with slow-roasted garlic flakes, oregano, and basil to create a versatile seasoning that adds an instant gourmet touch to any dish.',
    healthBenefits: [
      'Garlic boosts immune system function',
      'Herbs provide antioxidants',
      'Encourages using less salt due to high flavor profile'
    ],
    uses: ['Garlic bread', 'Roasted potatoes', 'Pasta dishes', 'Marinades'],
    variants: [
      { weight: '100g', price: 180 },
      { weight: '500g', price: 600 }
    ],
    images: ['https://images.unsplash.com/photo-1596040033229-a9821ebd058d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviews: 56
  },
  {
    id: 'bhut-jolokia-salt',
    name: 'Bhut Jolokia (Ghost Pepper) Salt',
    nameHi: 'भूत जोलोकिया नमक',
    category: 'Flavored',
    shortDesc: 'A fiery blend of natural salt and Assam\'s famous Ghost Pepper.',
    description: 'A true taste of Assam! We\'ve infused our pure rock salt with locally grown Bhut Jolokia (Ghost Pepper), one of the hottest chilies in the world. Use sparingly to add a smoky, intense heat to your favorite snacks.',
    healthBenefits: [
      'Capsaicin boosts metabolism',
      'Locally sourced ingredients support Assamese farmers',
      'Warming properties'
    ],
    uses: ['Sprinkle on fresh fruits (guava, pineapple)', 'Spicy margaritas', 'Grilled meats', 'Dips and chutneys'],
    variants: [
      { weight: '100g', price: 250 },
      { weight: '500g', price: 800 }
    ],
    images: ['https://images.unsplash.com/photo-1596646543206-382a9dbcdca9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviews: 42
  }
];
