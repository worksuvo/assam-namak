import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, ShoppingBag } from 'lucide-react';
import { useStore } from '../store/useStore';
import toast from 'react-hot-toast';

export const Checkout = () => {
  const { cart, cartTotal, clearCart } = useStore();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: 'Assam',
    pincode: '',
    paymentMethod: 'UPI'
  });

  const total = cartTotal();
  const shipping = total > 500 ? 0 : 50;
  const finalTotal = total + shipping;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    setIsProcessing(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      setOrderComplete(true);
      clearCart();
      toast.success('Order placed successfully!');
    }, 2000);
  };

  if (orderComplete) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center bg-stone-50 px-4">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6 text-green-600 shadow-sm">
          <CheckCircle2 className="w-12 h-12" />
        </div>
        <h2 className="text-3xl md:text-4xl font-serif font-bold text-stone-900 mb-4 text-center">Thank You for Your Order!</h2>
        <p className="text-stone-500 mb-8 max-w-md text-center text-lg">
          Your order #{Math.floor(Math.random() * 100000)} has been placed successfully. We will send you a confirmation email shortly.
        </p>
        <button 
          onClick={() => navigate('/shop')}
          className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 rounded-full font-bold transition-all shadow-lg shadow-teal-900/20 flex items-center gap-2"
        >
          Continue Shopping <ShoppingBag className="w-5 h-5" />
        </button>
      </div>
    );
  }

  if (cart.length === 0 && !orderComplete) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="min-h-screen bg-stone-50 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        <h1 className="text-3xl md:text-4xl font-serif font-bold text-stone-900 mb-10">Checkout</h1>
        
        <div className="flex flex-col lg:flex-row gap-12">
          
          {/* Checkout Form */}
          <div className="lg:w-2/3 bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-stone-100">
            <form onSubmit={handleSubmit} className="space-y-8">
              
              <div>
                <h2 className="text-xl font-bold text-stone-900 mb-4 border-b border-stone-100 pb-2">Contact Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-1">First Name</label>
                    <input required type="text" name="firstName" value={formData.firstName} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all" placeholder="Enter first name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-1">Last Name</label>
                    <input required type="text" name="lastName" value={formData.lastName} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all" placeholder="Enter last name" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-stone-700 mb-1">Email Address</label>
                    <input required type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all" placeholder="you@example.com" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-stone-700 mb-1">Phone Number</label>
                    <input required type="tel" name="phone" value={formData.phone} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all" placeholder="+91 98765 43210" />
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold text-stone-900 mb-4 border-b border-stone-100 pb-2">Shipping Address</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-stone-700 mb-1">Street Address</label>
                    <textarea required name="address" value={formData.address} onChange={handleChange} rows={2} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all resize-none" placeholder="123 Hill View Road, Dispur"></textarea>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-1">City</label>
                    <input required type="text" name="city" value={formData.city} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all" placeholder="Guwahati" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-1">State</label>
                    <select required name="state" value={formData.state} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all bg-white">
                      <option value="Assam">Assam</option>
                      <option value="Meghalaya">Meghalaya</option>
                      <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                      <option value="Nagaland">Nagaland</option>
                      <option value="Manipur">Manipur</option>
                      <option value="Mizoram">Mizoram</option>
                      <option value="Tripura">Tripura</option>
                      <option value="Other">Other (Shipping extra)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-1">PIN Code</label>
                    <input required type="text" name="pincode" value={formData.pincode} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all" placeholder="781005" />
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold text-stone-900 mb-4 border-b border-stone-100 pb-2">Payment Method</h2>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-4 border border-stone-200 rounded-xl cursor-pointer hover:bg-stone-50 transition-colors bg-white">
                    <input type="radio" name="paymentMethod" value="UPI" checked={formData.paymentMethod === 'UPI'} onChange={handleChange} className="w-4 h-4 text-teal-600 focus:ring-teal-500" />
                    <span className="font-medium text-stone-800 flex-grow">UPI (GPay, PhonePe, Paytm)</span>
                    <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg" alt="UPI" className="h-4" />
                  </label>
                  <label className="flex items-center gap-3 p-4 border border-stone-200 rounded-xl cursor-pointer hover:bg-stone-50 transition-colors bg-white">
                    <input type="radio" name="paymentMethod" value="Card" checked={formData.paymentMethod === 'Card'} onChange={handleChange} className="w-4 h-4 text-teal-600 focus:ring-teal-500" />
                    <span className="font-medium text-stone-800">Credit / Debit Card (Razorpay)</span>
                  </label>
                  <label className="flex items-center gap-3 p-4 border border-stone-200 rounded-xl cursor-pointer hover:bg-stone-50 transition-colors bg-white">
                    <input type="radio" name="paymentMethod" value="COD" checked={formData.paymentMethod === 'COD'} onChange={handleChange} className="w-4 h-4 text-teal-600 focus:ring-teal-500" />
                    <span className="font-medium text-stone-800">Cash on Delivery</span>
                  </label>
                </div>
              </div>

              <button 
                type="submit"
                disabled={isProcessing}
                className="w-full bg-stone-900 hover:bg-teal-700 disabled:bg-stone-400 text-white py-4 rounded-xl font-bold text-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
              >
                {isProcessing ? 'Processing Order...' : `Place Order - ₹${finalTotal}`}
              </button>

            </form>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:w-1/3">
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-stone-100 sticky top-28">
              <h2 className="text-xl font-bold text-stone-900 mb-6">Your Order</h2>
              
              <div className="space-y-4 mb-6 max-h-60 overflow-y-auto no-scrollbar">
                {cart.map((item, idx) => (
                  <div key={idx} className="flex gap-4 items-center">
                    <div className="w-16 h-16 bg-stone-100 rounded-lg overflow-hidden shrink-0 relative">
                      <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover" />
                      <span className="absolute -top-2 -right-2 bg-stone-600 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center z-10">{item.quantity}</span>
                    </div>
                    <div className="flex-grow">
                      <h4 className="text-sm font-bold text-stone-800 line-clamp-1">{item.product.name}</h4>
                      <p className="text-xs text-stone-500">{item.variant.weight}</p>
                    </div>
                    <div className="text-sm font-bold text-stone-900 shrink-0">
                      ₹{item.variant.price * item.quantity}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="space-y-3 mb-6 text-sm text-stone-600 border-t border-stone-100 pt-6">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-medium text-stone-900">₹{total}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span className="font-medium text-stone-900">{shipping === 0 ? 'Free' : `₹${shipping}`}</span>
                </div>
              </div>
              
              <div className="border-t border-stone-100 pt-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-lg font-bold text-stone-900">Total</span>
                  <span className="text-2xl font-bold text-teal-700">₹{finalTotal}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
