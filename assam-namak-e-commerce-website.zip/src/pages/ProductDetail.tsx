import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Star, Heart, Check, ShieldCheck, Truck, ChevronRight } from 'lucide-react';
import { products } from '../data/products';
import { useStore } from '../store/useStore';
import { cn } from '../lib/utils';
import toast from 'react-hot-toast';

export const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const product = products.find((p) => p.id === id);
  const [selectedVariant, setSelectedVariant] = useState(product?.variants[0]);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  const { addToCart, toggleWishlist, wishlist } = useStore();

  useEffect(() => {
    if (!product) {
      navigate('/shop');
    } else {
      setSelectedVariant(product.variants[0]);
    }
  }, [id, navigate, product]);

  if (!product || !selectedVariant) return null;

  const isWishlisted = wishlist.includes(product.id);

  const handleAddToCart = () => {
    addToCart(product, selectedVariant, quantity);
    toast.success(`Added ${quantity}x ${product.name} to cart!`);
  };

  return (
    <div className="bg-stone-50 min-h-screen py-10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb */}
        <nav className="flex items-center text-sm font-medium text-stone-500 mb-8">
          <Link to="/" className="hover:text-teal-700">Home</Link>
          <ChevronRight className="w-4 h-4 mx-2" />
          <Link to="/shop" className="hover:text-teal-700">Shop</Link>
          <ChevronRight className="w-4 h-4 mx-2" />
          <span className="text-stone-900">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 xl:gap-20">
          
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-stone-100 rounded-2xl overflow-hidden relative">
              <img 
                src={product.images[activeImage]} 
                alt={product.name} 
                className="w-full h-full object-cover transition-opacity duration-300"
              />
              <button 
                onClick={() => {
                  toggleWishlist(product.id);
                  toast.success(isWishlisted ? 'Removed from wishlist' : 'Added to wishlist');
                }}
                className="absolute top-4 right-4 p-3 bg-white/80 backdrop-blur-md rounded-full text-stone-600 hover:text-red-500 transition-colors shadow-sm z-10"
              >
                <Heart className={cn("w-6 h-6", isWishlisted && "fill-red-500 text-red-500")} />
              </button>
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-4 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setActiveImage(idx)}
                    className={cn(
                      "w-24 h-24 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-colors",
                      activeImage === idx ? "border-teal-600" : "border-transparent"
                    )}
                  >
                    <img src={img} alt={`${product.name} - ${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="flex flex-col">
            <div className="mb-2">
              <span className="text-sm font-bold text-teal-700 uppercase tracking-wider">{product.category}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-stone-900 mb-2">{product.name}</h1>
            <p className="text-lg font-medium text-stone-500 mb-4">{product.nameHi}</p>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center text-amber-500">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={cn("w-5 h-5", i < Math.floor(product.rating) ? "fill-amber-500" : "fill-stone-200 text-stone-200")} />
                ))}
              </div>
              <span className="text-sm font-medium text-stone-600">
                {product.rating} ({product.reviews} reviews)
              </span>
            </div>
            
            <div className="text-3xl font-bold text-stone-900 mb-8">
              ₹{selectedVariant.price} <span className="text-base font-normal text-stone-500">MRP</span>
            </div>
            
            <p className="text-stone-700 leading-relaxed mb-8 text-lg border-b border-stone-200 pb-8">
              {product.description}
            </p>

            {/* Variants */}
            <div className="mb-8">
              <h3 className="text-sm font-bold text-stone-900 uppercase mb-4">Select Size</h3>
              <div className="flex flex-wrap gap-4">
                {product.variants.map((variant) => (
                  <button
                    key={variant.weight}
                    onClick={() => setSelectedVariant(variant)}
                    className={cn(
                      "px-6 py-3 rounded-xl border-2 font-medium transition-all",
                      selectedVariant.weight === variant.weight
                        ? "border-teal-600 bg-teal-50 text-teal-900 shadow-sm"
                        : "border-stone-200 bg-white text-stone-600 hover:border-stone-300"
                    )}
                  >
                    {variant.weight}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity & Add to Cart */}
            <div className="flex items-center gap-6 mb-10 border-b border-stone-200 pb-10">
              <div className="flex items-center bg-white border border-stone-200 rounded-full h-14">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-12 h-full flex items-center justify-center text-stone-600 hover:text-teal-700 font-medium"
                >
                  -
                </button>
                <span className="w-12 text-center font-bold text-stone-900">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-12 h-full flex items-center justify-center text-stone-600 hover:text-teal-700 font-medium"
                >
                  +
                </button>
              </div>
              
              <button
                onClick={handleAddToCart}
                className="flex-1 h-14 bg-teal-600 hover:bg-teal-700 text-white rounded-full font-bold text-lg transition-all transform active:scale-95 shadow-lg shadow-teal-900/20"
              >
                Add to Cart - ₹{selectedVariant.price * quantity}
              </button>
            </div>
            
            {/* Benefits & Features */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-6 h-6 text-teal-600 shrink-0" />
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">100% Authentic</h4>
                  <p className="text-xs text-stone-500">Ethically sourced</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Truck className="w-6 h-6 text-teal-600 shrink-0" />
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">Fast Delivery</h4>
                  <p className="text-xs text-stone-500">Free over ₹500 in Assam</p>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Detailed Info Tabs equivalent (Stacked) */}
        <div className="mt-20 max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-stone-100">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              
              <div>
                <h3 className="text-2xl font-serif font-bold text-stone-900 mb-6 flex items-center gap-2">
                  Health Benefits
                </h3>
                <ul className="space-y-4">
                  {product.healthBenefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-teal-100 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-4 h-4 text-teal-700" />
                      </div>
                      <span className="text-stone-700 leading-relaxed">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-2xl font-serif font-bold text-stone-900 mb-6 flex items-center gap-2">
                  Best Uses
                </h3>
                <div className="flex flex-wrap gap-3">
                  {product.uses.map((use, idx) => (
                    <span key={idx} className="px-4 py-2 bg-stone-100 text-stone-700 font-medium rounded-lg text-sm">
                      {use}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
