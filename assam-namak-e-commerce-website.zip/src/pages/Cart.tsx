import { Link, useNavigate } from 'react-router-dom';
import { Trash2, ArrowRight, ShoppingBag } from 'lucide-react';
import { useStore } from '../store/useStore';

export const Cart = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useStore();
  const navigate = useNavigate();

  const total = cartTotal();
  const shipping = total > 500 ? 0 : 50; // Free shipping over 500
  const finalTotal = total > 0 ? total + shipping : 0;

  if (cart.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center bg-stone-50 px-4">
        <div className="w-24 h-24 bg-teal-100 rounded-full flex items-center justify-center mb-6 text-teal-600">
          <ShoppingBag className="w-12 h-12" />
        </div>
        <h2 className="text-3xl font-serif font-bold text-stone-900 mb-4">Your Cart is Empty</h2>
        <p className="text-stone-500 mb-8 max-w-md text-center">
          Looks like you haven't added any natural salts to your cart yet. Let's change that!
        </p>
        <Link 
          to="/shop" 
          className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 rounded-full font-bold transition-all shadow-lg shadow-teal-900/20 flex items-center gap-2"
        >
          Explore Shop <ArrowRight className="w-5 h-5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        <h1 className="text-3xl md:text-4xl font-serif font-bold text-stone-900 mb-10">Shopping Cart</h1>
        
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Cart Items */}
          <div className="lg:w-2/3 space-y-6">
            {cart.map((item) => (
              <div key={`${item.product.id}-${item.variant.weight}`} className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm border border-stone-100 flex flex-col sm:flex-row gap-6 items-center sm:items-start">
                <Link to={`/product/${item.product.id}`} className="w-32 h-32 shrink-0 bg-stone-100 rounded-xl overflow-hidden">
                  <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover hover:scale-105 transition-transform" />
                </Link>
                
                <div className="flex-grow flex flex-col h-full w-full">
                  <div className="flex justify-between items-start mb-2">
                    <Link to={`/product/${item.product.id}`} className="text-lg font-bold text-stone-900 hover:text-teal-700 transition-colors">
                      {item.product.name}
                    </Link>
                    <button 
                      onClick={() => removeFromCart(item.product.id, item.variant.weight)}
                      className="p-2 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                      title="Remove Item"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <p className="text-sm font-medium text-stone-500 mb-4">{item.variant.weight} Pack</p>
                  
                  <div className="flex items-center justify-between mt-auto w-full">
                    <div className="flex items-center bg-stone-50 border border-stone-200 rounded-lg h-10">
                      <button 
                        onClick={() => updateQuantity(item.product.id, item.variant.weight, item.quantity - 1)}
                        className="w-10 h-full flex items-center justify-center text-stone-600 hover:text-teal-700 font-medium"
                      >
                        -
                      </button>
                      <span className="w-10 text-center font-bold text-stone-900 text-sm">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.product.id, item.variant.weight, item.quantity + 1)}
                        className="w-10 h-full flex items-center justify-center text-stone-600 hover:text-teal-700 font-medium"
                      >
                        +
                      </button>
                    </div>
                    
                    <div className="text-right">
                      <span className="text-sm text-stone-500 block mb-1">₹{item.variant.price} each</span>
                      <span className="text-lg font-bold text-stone-900">₹{item.variant.price * item.quantity}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-stone-100 sticky top-28">
              <h2 className="text-xl font-bold text-stone-900 mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6 text-sm md:text-base">
                <div className="flex justify-between text-stone-600">
                  <span>Subtotal</span>
                  <span className="font-medium text-stone-900">₹{total}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Shipping</span>
                  <span className="font-medium text-stone-900">{shipping === 0 ? 'Free' : `₹${shipping}`}</span>
                </div>
                {shipping > 0 && (
                  <div className="text-xs text-amber-600 bg-amber-50 p-2 rounded text-center">
                    Add ₹{500 - total} more to your cart for free shipping!
                  </div>
                )}
              </div>
              
              <div className="border-t border-stone-100 pt-6 mb-8">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-lg font-bold text-stone-900">Total</span>
                  <span className="text-2xl font-bold text-teal-700">₹{finalTotal}</span>
                </div>
                <p className="text-xs text-stone-500 text-right">Includes all taxes</p>
              </div>
              
              <button 
                onClick={() => navigate('/checkout')}
                className="w-full bg-stone-900 hover:bg-teal-700 text-white py-4 rounded-xl font-bold text-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
              >
                Proceed to Checkout <ArrowRight className="w-5 h-5" />
              </button>

              <div className="mt-6 flex items-center justify-center gap-2">
                <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg" alt="UPI" className="h-4 opacity-50 grayscale hover:grayscale-0 transition-all" />
                <span className="text-stone-300">|</span>
                <span className="text-xs font-bold text-stone-400">RAZORPAY</span>
                <span className="text-stone-300">|</span>
                <span className="text-xs font-bold text-stone-400">COD</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
