import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Star, Truck, ShieldCheck, Leaf } from 'lucide-react';
import { products } from '../data/products';

export const Home = () => {
  const featuredProducts = products.slice(0, 3);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[90vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/hero.jpg"
            alt="Premium Natural Salts"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-stone-900/40 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900/80 via-transparent to-transparent" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <span className="inline-block py-1 px-3 rounded-full bg-teal-800/80 text-teal-100 text-sm font-semibold tracking-wider uppercase mb-6 backdrop-blur-sm">
            From the Hills of Assam
          </span>
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6 drop-shadow-lg leading-tight">
            Pure Natural Salts <br /> for a Healthier You
          </h1>
          <p className="text-lg md:text-xl text-stone-200 mb-10 max-w-2xl mx-auto drop-shadow-md">
            Discover the rich flavors and natural health benefits of our authentic, ethically sourced Indian salts.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/shop"
              className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 rounded-full font-medium text-lg transition-all transform hover:scale-105 shadow-lg shadow-teal-900/20 flex items-center gap-2"
            >
              Shop Now <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/about"
              className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white px-8 py-4 rounded-full font-medium text-lg transition-all"
            >
              Our Story
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-white border-b border-stone-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center gap-3 p-6">
              <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-stone-800">100% Pure & Unrefined</h3>
              <p className="text-stone-600">No anti-caking agents, no bleaching. Just pure salt as nature intended.</p>
            </div>
            <div className="flex flex-col items-center gap-3 p-6">
              <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2">
                <Leaf className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-stone-800">Rich in Minerals</h3>
              <p className="text-stone-600">Packed with over 80 trace minerals essential for your body's wellness.</p>
            </div>
            <div className="flex flex-col items-center gap-3 p-6">
              <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2">
                <Truck className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-stone-800">Fast Delivery</h3>
              <p className="text-stone-600">Free delivery within Assam for orders over ₹500. Shipped within 2-5 days.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-stone-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-stone-800 mb-4">Our Bestsellers</h2>
            <p className="text-stone-600 text-lg">Experience the distinct flavors and therapeutic properties of our most loved natural salts.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {featuredProducts.map((product) => (
              <Link key={product.id} to={`/product/${product.id}`} className="group block bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-stone-100">
                <div className="aspect-[4/3] overflow-hidden bg-stone-100 relative">
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-teal-800 shadow-sm">
                    {product.category}
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-stone-800 group-hover:text-teal-700 transition-colors">
                      {product.name}
                    </h3>
                  </div>
                  <p className="text-sm font-medium text-stone-500 mb-4">{product.nameHi}</p>
                  <p className="text-stone-600 text-sm mb-6 line-clamp-2">
                    {product.shortDesc}
                  </p>
                  <div className="flex items-center justify-between border-t border-stone-100 pt-4">
                    <span className="text-lg font-bold text-stone-900">From ₹{product.variants[0].price}</span>
                    <span className="flex items-center text-sm font-medium text-amber-500 gap-1">
                      <Star className="w-4 h-4 fill-amber-500" /> {product.rating}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/shop" className="inline-flex items-center gap-2 text-teal-700 font-bold hover:text-teal-800 transition-colors">
              View All Products <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Health Benefits / Story */}
      <section className="py-24 bg-stone-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-3xl md:text-5xl font-serif font-bold leading-tight">Why Choose Natural Salts over Refined White Salt?</h2>
              <div className="space-y-6">
                {[
                  'Contains 84+ essential trace minerals like potassium, magnesium, and calcium.',
                  'No chemical processing or harmful anti-caking agents.',
                  'Balances pH levels and supports proper hydration.',
                  'Lower sodium levels help maintain healthy blood pressure.'
                ].map((point, idx) => (
                  <div key={idx} className="flex gap-4">
                    <CheckCircle2 className="w-6 h-6 text-teal-500 shrink-0 mt-1" />
                    <p className="text-lg text-stone-300">{point}</p>
                  </div>
                ))}
              </div>
              <div className="pt-6">
                <Link to="/about" className="bg-teal-600 hover:bg-teal-500 text-white px-8 py-4 rounded-full font-medium transition-colors inline-block">
                  Read Our Story
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-full overflow-hidden border-8 border-stone-800 relative z-10">
                <img src="/images/black-salt.jpg" alt="Black Salt Macro" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-8 -left-8 w-64 h-64 bg-teal-900 rounded-full blur-3xl opacity-50 z-0"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-stone-100">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-stone-800 mb-16">Loved by Health Enthusiasts</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { text: "The quality of the Kala Namak is unmatched. It has that authentic pungent aroma which makes my chaats taste exactly like the ones on the streets of Delhi. Highly recommended!", author: "Priya S.", location: "Guwahati" },
              { text: "Switched to Assam Namak's Pink Salt for my family's everyday cooking. The granules dissolve perfectly and I feel great knowing we aren't consuming microplastics or bleach.", author: "Rajiv M.", location: "Jorhat" },
              { text: "Their Bhut Jolokia infused salt is incredible! It gives such a wonderful kick to my grilled paneer and fruits. It's spicy, salty, and totally addictive.", author: "Ankita B.", location: "Dibrugarh" }
            ].map((review, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl shadow-sm text-left">
                <div className="flex text-amber-400 mb-4">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-5 h-5 fill-current" />)}
                </div>
                <p className="text-stone-600 italic mb-6">"{review.text}"</p>
                <div>
                  <h4 className="font-bold text-stone-900">{review.author}</h4>
                  <span className="text-sm text-stone-500">{review.location}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
