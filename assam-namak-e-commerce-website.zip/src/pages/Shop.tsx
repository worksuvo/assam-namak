import { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Star, Filter, Heart, ShoppingBag } from 'lucide-react';
import { products, Product } from '../data/products';
import { useStore } from '../store/useStore';
import { cn } from '../lib/utils';
import toast from 'react-hot-toast';

export const Shop = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('category');
  
  const [activeCategory, setActiveCategory] = useState<string>(categoryParam || 'All');
  
  const { toggleWishlist, wishlist, addToCart } = useStore();

  const categories = ['All', 'Black Salt', 'Pink Salt', 'Rock Salt', 'Flavored'];

  const filteredProducts = useMemo(() => {
    if (activeCategory === 'All') return products;
    return products.filter((p) => p.category === activeCategory);
  }, [activeCategory]);

  const handleCategoryChange = (cat: string) => {
    setActiveCategory(cat);
    if (cat === 'All') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', cat);
    }
    setSearchParams(searchParams);
  };

  const handleAddToCart = (e: React.MouseEvent, product: Product) => {
    e.preventDefault();
    addToCart(product, product.variants[0], 1);
    toast.success(`Added ${product.name} to cart!`);
  };

  const handleToggleWishlist = (e: React.MouseEvent, productId: string) => {
    e.preventDefault();
    toggleWishlist(productId);
    toast.success(
      wishlist.includes(productId) 
        ? 'Removed from wishlist' 
        : 'Added to wishlist'
    );
  };

  return (
    <div className="min-h-screen bg-stone-50 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-12 text-center max-w-2xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Our Premium Salts</h1>
          <p className="text-stone-600 text-lg">
            Discover our collection of 100% natural, unrefined salts sourced from pristine environments for your health and culinary delight.
          </p>
        </div>

        {/* Categories / Filters */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 w-full md:w-auto no-scrollbar">
            <Filter className="w-5 h-5 text-stone-400 shrink-0 mr-2" />
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => handleCategoryChange(cat)}
                className={cn(
                  "px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all",
                  activeCategory === cat
                    ? "bg-teal-700 text-white shadow-md shadow-teal-900/20"
                    : "bg-white text-stone-600 hover:bg-stone-100 border border-stone-200"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="text-sm font-medium text-stone-500 w-full md:w-auto text-right">
            Showing {filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <Link key={product.id} to={`/product/${product.id}`} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-stone-100 flex flex-col h-full relative">
              
              {/* Wishlist Button */}
              <button 
                onClick={(e) => handleToggleWishlist(e, product.id)}
                className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-sm hover:bg-white transition-colors"
              >
                <Heart className={cn("w-5 h-5 transition-colors", wishlist.includes(product.id) ? "fill-red-500 text-red-500" : "text-stone-400 hover:text-red-500")} />
              </button>

              <div className="aspect-[4/3] overflow-hidden bg-stone-100 relative">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-teal-800 shadow-sm">
                  {product.category}
                </div>
              </div>

              <div className="p-5 flex flex-col flex-grow">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="text-lg font-bold text-stone-800 group-hover:text-teal-700 transition-colors line-clamp-1">
                    {product.name}
                  </h3>
                </div>
                <p className="text-xs font-medium text-stone-400 mb-3">{product.nameHi}</p>
                
                <p className="text-stone-600 text-sm mb-4 line-clamp-2 flex-grow">
                  {product.shortDesc}
                </p>

                <div className="flex items-center mb-4 text-xs font-medium text-amber-500 gap-1">
                  <Star className="w-4 h-4 fill-amber-500" /> {product.rating} ({product.reviews} reviews)
                </div>
                
                <div className="flex items-center justify-between border-t border-stone-100 pt-4 mt-auto">
                  <div className="flex flex-col">
                    <span className="text-xs text-stone-500 mb-0.5">Starting at</span>
                    <span className="text-lg font-bold text-stone-900">₹{product.variants[0].price}</span>
                  </div>
                  
                  <button
                    onClick={(e) => handleAddToCart(e, product)}
                    className="w-10 h-10 bg-teal-50 hover:bg-teal-600 text-teal-700 hover:text-white rounded-full flex items-center justify-center transition-colors shadow-sm"
                    title="Quick Add to Cart"
                  >
                    <ShoppingBag className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <h3 className="text-2xl font-bold text-stone-700 mb-2">No products found</h3>
            <p className="text-stone-500">Try changing the category filter to see more products.</p>
            <button 
              onClick={() => handleCategoryChange('All')}
              className="mt-6 px-6 py-2 bg-teal-600 text-white rounded-full hover:bg-teal-700"
            >
              View All Products
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
