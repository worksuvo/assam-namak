import { Heart, Sprout, ShieldCheck, Droplets } from 'lucide-react';

export const About = () => {
  return (
    <div className="bg-stone-50 min-h-screen">
      {/* Hero */}
      <section className="relative h-[50vh] min-h-[400px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/hero.jpg"
            alt="Salt Mines"
            className="w-full h-full object-cover grayscale"
          />
          <div className="absolute inset-0 bg-teal-900/60 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900/90 to-transparent" />
        </div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-4 drop-shadow-lg">Our Story</h1>
          <p className="text-lg md:text-xl text-teal-100 max-w-2xl mx-auto drop-shadow-md font-medium">
            From the deep mines of the Himalayas and indigenous local sources, bringing nature's purest crystals to your kitchen.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="prose prose-lg prose-stone max-w-none">
            <h2 className="text-3xl font-serif font-bold text-stone-900 mb-6 text-center">Rooted in Assam, Dedicated to Purity</h2>
            <p className="text-stone-600 leading-relaxed text-center mb-16 max-w-2xl mx-auto">
              Assam Namak started as a humble family-run endeavor in Guwahati. Growing up, we realized that the commercial white salt we consumed daily was heavily processed, stripped of essential minerals, and laden with anti-caking chemicals. We embarked on a journey to find healthier, natural alternatives.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20 items-center">
              <div>
                <img src="/images/pink-salt.jpg" alt="Pure Salt" className="rounded-2xl shadow-lg w-full h-80 object-cover" />
              </div>
              <div>
                <h3 className="text-2xl font-serif font-bold text-stone-900 mb-4">Ethical Sourcing</h3>
                <p className="text-stone-600 leading-relaxed mb-4">
                  We partner directly with artisanal miners in the Himalayan regions and local communities to source raw, unrefined salts. Every batch is hand-sorted to ensure zero impurities, preserving the 80+ trace minerals that your body needs.
                </p>
                <p className="text-stone-600 leading-relaxed">
                  Our flavored salts, like the Bhut Jolokia infusion, use ingredients grown right here in Assam, supporting local farmers and sustainable agriculture.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-20 text-center">
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2 shadow-sm">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-stone-900">100% Authentic</h4>
                <p className="text-sm text-stone-500">Unrefined & pure</p>
              </div>
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2 shadow-sm">
                  <Droplets className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-stone-900">Mineral Rich</h4>
                <p className="text-sm text-stone-500">84+ trace minerals</p>
              </div>
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2 shadow-sm">
                  <Heart className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-stone-900">Health Focus</h4>
                <p className="text-sm text-stone-500">Aids digestion & pH</p>
              </div>
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-full flex items-center justify-center mb-2 shadow-sm">
                  <Sprout className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-stone-900">Sustainable</h4>
                <p className="text-sm text-stone-500">Eco-friendly packaging</p>
              </div>
            </div>

            <div className="bg-stone-900 text-white rounded-3xl p-8 md:p-12 text-center">
              <h3 className="text-3xl font-serif font-bold mb-4">Our Mission</h3>
              <p className="text-stone-300 leading-relaxed max-w-2xl mx-auto text-lg">
                To replace every packet of bleached, chemical-laden table salt in Indian households with our pure, mineral-rich natural salts, bringing back the forgotten health benefits of traditional Indian diets.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
