import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, Variant } from '../data/products';

export interface CartItem {
  product: Product;
  variant: Variant;
  quantity: number;
}

interface StoreState {
  cart: CartItem[];
  wishlist: string[];
  addToCart: (product: Product, variant: Variant, quantity?: number) => void;
  removeFromCart: (productId: string, variantWeight: string) => void;
  updateQuantity: (productId: string, variantWeight: string, quantity: number) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  cartTotal: () => number;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      cart: [],
      wishlist: [],
      
      addToCart: (product, variant, quantity = 1) => {
        set((state) => {
          const existingItem = state.cart.find(
            (item) => item.product.id === product.id && item.variant.weight === variant.weight
          );
          
          if (existingItem) {
            return {
              cart: state.cart.map((item) =>
                item.product.id === product.id && item.variant.weight === variant.weight
                  ? { ...item, quantity: item.quantity + quantity }
                  : item
              ),
            };
          }
          
          return {
            cart: [...state.cart, { product, variant, quantity }],
          };
        });
      },
      
      removeFromCart: (productId, variantWeight) => {
        set((state) => ({
          cart: state.cart.filter(
            (item) => !(item.product.id === productId && item.variant.weight === variantWeight)
          ),
        }));
      },
      
      updateQuantity: (productId, variantWeight, quantity) => {
        if (quantity < 1) return;
        set((state) => ({
          cart: state.cart.map((item) =>
            item.product.id === productId && item.variant.weight === variantWeight
              ? { ...item, quantity }
              : item
          ),
        }));
      },
      
      clearCart: () => set({ cart: [] }),
      
      toggleWishlist: (productId) => {
        set((state) => ({
          wishlist: state.wishlist.includes(productId)
            ? state.wishlist.filter((id) => id !== productId)
            : [...state.wishlist, productId],
        }));
      },
      
      cartTotal: () => {
        const { cart } = get();
        return cart.reduce((total, item) => total + item.variant.price * item.quantity, 0);
      },
    }),
    {
      name: 'assam-namak-store',
    }
  )
);
