import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-stone-900 text-stone-300 py-12 lg:py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-serif font-bold text-white mb-4">Assam Namak</h3>
            <p className="text-sm text-stone-400 max-w-xs">
              Premium natural salts sourced ethically from the pristine Himalayan ranges and local mines. Bringing pure flavor and health to your everyday cooking.
            </p>
            <div className="flex gap-4 pt-4">
              <a href="#" className="hover:text-teal-400 transition-colors text-sm underline">Facebook</a>
              <a href="#" className="hover:text-teal-400 transition-colors text-sm underline">Instagram</a>
              <a href="#" className="hover:text-teal-400 transition-colors text-sm underline">Twitter</a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3 text-sm">
              <li><Link to="/shop" className="hover:text-teal-400 transition-colors">Shop All Salts</Link></li>
              <li><Link to="/about" className="hover:text-teal-400 transition-colors">Our Story</Link></li>
              <li><Link to="/contact" className="hover:text-teal-400 transition-colors">Contact Us</Link></li>
              <li><a href="#" className="hover:text-teal-400 transition-colors">FAQs</a></li>
              <li><a href="#" className="hover:text-teal-400 transition-colors">Shipping & Returns</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-lg font-bold text-white mb-6">Our Salts</h4>
            <ul className="space-y-3 text-sm">
              <li><Link to="/shop?category=Black+Salt" className="hover:text-teal-400 transition-colors">Black Salt (Kala Namak)</Link></li>
              <li><Link to="/shop?category=Pink+Salt" className="hover:text-teal-400 transition-colors">Himalayan Pink Salt</Link></li>
              <li><Link to="/shop?category=Rock+Salt" className="hover:text-teal-400 transition-colors">Rock Salt (Sendha Namak)</Link></li>
              <li><Link to="/shop?category=Flavored" className="hover:text-teal-400 transition-colors">Flavored Salts</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold text-white mb-6">Contact Us</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-teal-500 shrink-0" />
                <span>123 Hill View Road, Dispur<br/>Guwahati, Assam 781005<br/>India</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-teal-500 shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-teal-500 shrink-0" />
                <a href="mailto:hello@assamnamak.com" className="hover:text-teal-400">hello@assamnamak.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-stone-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-stone-500">
          <p>&copy; {new Date().getFullYear()} Assam Namak. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
