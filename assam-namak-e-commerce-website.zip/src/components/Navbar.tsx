import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Heart, Menu, X, Search } from 'lucide-react';
import { useStore } from '../store/useStore';
import { cn } from '../lib/utils';

export const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const { cart, wishlist } = useStore();
  const location = useLocation();

  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Shop', path: '/shop' },
    { name: 'About Us', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-stone-50/90 backdrop-blur-md border-b border-stone-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-teal-700 rounded-full flex items-center justify-center">
              <span className="text-white font-serif font-bold text-xl">A</span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif font-bold text-2xl text-stone-800 leading-none">Assam Namak</span>
              <span className="text-xs text-stone-500 font-medium tracking-widest uppercase">Premium Pure Salts</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-teal-700",
                  location.pathname === link.path ? "text-teal-700" : "text-stone-600"
                )}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Icons */}
          <div className="flex items-center gap-4 lg:gap-6">
            <button className="text-stone-600 hover:text-teal-700 hidden sm:block">
              <Search className="w-5 h-5" />
            </button>
            <Link to="/shop" className="text-stone-600 hover:text-teal-700 relative hidden sm:block">
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </Link>
            <Link to="/cart" className="text-stone-600 hover:text-teal-700 relative flex items-center gap-2">
              <div className="relative">
                <ShoppingCart className="w-5 h-5" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-teal-700 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </div>
              <span className="hidden lg:block text-sm font-medium">Cart</span>
            </Link>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-stone-600"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-stone-50 border-t border-stone-200">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "block px-3 py-2 rounded-md text-base font-medium",
                  location.pathname === link.path
                    ? "bg-stone-200 text-teal-800"
                    : "text-stone-600 hover:bg-stone-100"
                )}
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            <div className="mt-4 pt-4 border-t border-stone-200 flex items-center gap-4 px-3">
              <Link to="/shop" onClick={() => setIsOpen(false)} className="flex items-center gap-2 text-stone-600">
                <Heart className="w-5 h-5" />
                <span>Wishlist ({wishlist.length})</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
